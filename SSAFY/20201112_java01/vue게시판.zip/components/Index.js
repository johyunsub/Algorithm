export default {
  template: `
  <div>
    <div>
      <h1 class="text-center"><img src="./catimg.jpg" alt="고양이 사진"/></h1>
    </div>
    <div>
      만든이 : johyeonseop
    </div>
  </div>`,
};
