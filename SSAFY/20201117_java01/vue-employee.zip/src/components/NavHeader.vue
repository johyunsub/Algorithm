<template>
  <p>
    <router-link to="/list">게시판</router-link>
  </p>
</template>

<script>
export default {
  name: 'NavHeader',
};
</script>
