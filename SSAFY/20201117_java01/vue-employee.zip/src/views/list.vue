<template>
  <div class="about">
   
        <div>
            <input type="text" id="sname" ref="name" v-model="name"/>
            <button @click="search">검색</button>
        </div>
        <div v-if="items.length">
            <table class="">
                <tr>
                    <th>사원 아이디</th>
                    <th>사원명</th>
                    <th>부서</th>
                    <th>직책</th>
                    <th>연봉</th>
                    <th>퇴사</th>
                </tr>
                <tr v-for="(item,index) in items" :key="index" :class="id">
                    <td>{{item.id}}</td>
                    <td>{{item.name}}</td>
                    <td v-if="item.dept_id===118">사장</td>
                    <td v-else-if="item.dept_id===110">기획부장</td>
                    <td v-else-if="item.dept_id===102">영업부</td>
                    <td v-else-if="item.dept_id===101">총무부</td>
                    <td v-else-if="item.dept_id===111">인사부장</td>
                    <td v-else-if="item.dept_id===112">기획부</td>
                    <td v-else-if="item.dept_id===113">영업대표이사</td>
                    <td v-else-if="item.dept_id===104">사원</td>
                    <td v-else-if="item.dept_id===105">사원</td>
                    <td v-else-if="item.dept_id===106">사원</td>
                    <td>{{item.title}}</td>
                    <td>{{item.salary}}</td>
                    <td><button class="" @click="del(item.id)">퇴사</button></td>
                </tr>
            </table>
        </div>
        <div v-else>
        글이 없습니다.
        </div>
        <div class="">
            <button class="" @click="movePage">등록</button>
        </div>

  </div>
</template>
<script>
import axios from 'axios';
export default {
  name: 'list',
  data() {
    return {
      items: [],
      name: '',
      id: '',
    };
  },

  created() {
    axios
      .get('http://localhost:8097/hrmboot/api/employee/all')
      .then(({ data }) => {
        this.items = data;
      });
  },
  methods: {
    moveHome() {
      this.$router.push('/');
    },
    movePage() {
      this.$router.push('/add');
    },
    search() {
      let na = this.name;
      if (na == '') {
        axios
          .get('http://localhost:8097/hrmboot/api/employee/all')
          .then(({ data }) => {
            this.items = data;
          });
      } else {
        axios
          .get('http://localhost:8097/hrmboot/api/name?name=' + na)
          .then(({ data }) => {
            this.items = data;
          });
      }
    },
    del(id) {
      let na = id;
      console.log(na)
      axios
      .get('http://localhost:8097/hrmboot/api/delete?no=' + na)
      .then(({ data }) => {
            this.items = data;
            let msg = '퇴사 완료되었습니다.';
            alert(msg);
            this.moveHome();
          });
    },
  },
};
</script>

