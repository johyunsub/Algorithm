import Vue from 'vue';
import VueRouter from 'vue-router';
import List from '@/views/list.vue';
import add from '@/views/add.vue';

Vue.use(VueRouter);

const routes = [
  {
    path: '/',
    name: 'home',
    component: add,
  },
  {
    path: '/add',
    name: 'add',
    component: add,
  },
  {
    path: '/list',
    name: 'list',
    component: List,
  },
];

const router = new VueRouter({
  mode: 'hash',
  base: process.env.BASE_URL,
  routes,
});


export default router;